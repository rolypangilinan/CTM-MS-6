import 'package:flutter/material.dart';
import 'package:usb_serial/usb_serial.dart';

import 'app_controller.dart';
import 'models.dart';

void main() {
  runApp(const DelvoApp());
}

class DelvoApp extends StatefulWidget {
  const DelvoApp({super.key});

  @override
  State<DelvoApp> createState() => _DelvoAppState();
}

class _DelvoAppState extends State<DelvoApp> {
  final controller = DelvoController();
  late final Future<void> init = controller.initialize();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DELVO Screw Fastening Monitor',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF003E92)),
        useMaterial3: true,
      ),
      home: FutureBuilder<void>(
        future: init,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (snap.hasError) {
            return Scaffold(body: Center(child: Text('Initialization error: ${snap.error}')));
          }
          return MonitorPage(controller: controller);
        },
      ),
    );
  }
}

class MonitorPage extends StatefulWidget {
  const MonitorPage({super.key, required this.controller});
  final DelvoController controller;

  @override
  State<MonitorPage> createState() => _MonitorPageState();
}

class _MonitorPageState extends State<MonitorPage> {
  DelvoController get controller => widget.controller;
  final TextEditingController _qrInput = TextEditingController();
  final FocusNode _qrFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _qrFocus.requestFocus());
  }

  @override
  void dispose() {
    _qrInput.dispose();
    _qrFocus.dispose();
    super.dispose();
  }

  Future<void> _submitKitting(String value) async {
    final ok = await controller.registerKittingScan(value);
    if (!mounted) return;
    if (ok) {
      _qrInput.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kitting QR registered: ${controller.currentKittingNumber}'), duration: const Duration(seconds: 1)),
      );
    }
    _qrFocus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final resultColor = controller.result == 'OK'
            ? Colors.lightBlue
            : controller.result == 'NG'
                ? Colors.red
                : const Color(0xFF003E92);
        return Scaffold(
          appBar: AppBar(
            title: Text('${controller.system.deviceName} - Process ${controller.communication.processNumber} - Screw Fastening Monitor'),
            backgroundColor: const Color(0xFF003E92),
            foregroundColor: Colors.white,
            actions: [
              IconButton(
                tooltip: 'Focus Kitting QR scanner',
                icon: const Icon(Icons.qr_code_scanner),
                onPressed: () => _qrFocus.requestFocus(),
              ),
              IconButton(
                tooltip: 'Judgement value setting',
                icon: const Icon(Icons.fact_check_outlined),
                onPressed: () => _open(context, JudgmentSettingsPage(controller: controller)),
              ),
              IconButton(
                tooltip: 'Torque conversion',
                icon: const Icon(Icons.calculate_outlined),
                onPressed: () => _open(context, TorqueConversionPage(controller: controller)),
              ),
              IconButton(
                tooltip: 'Communication setting',
                icon: const Icon(Icons.cable),
                onPressed: () => _open(context, CommunicationPage(controller: controller)),
              ),
              IconButton(
                tooltip: 'System setting',
                icon: const Icon(Icons.settings),
                onPressed: () => _open(context, SystemSettingsPage(controller: controller)),
              ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: [
                _statusBar(context),
                const SizedBox(height: 10),
                _kittingCard(),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 3,
                      child: Column(
                        children: [
                          _valueCard('Operation channel', controller.channel?.toString() ?? '--'),
                          _valueCard('Converted Current', controller.convertedCurrent?.toString() ?? '--'),
                          _valueCard(
                            'Converted Torque',
                            controller.convertedTorque == null
                                ? '-- Nm'
                                : '${controller.convertedTorque!.toStringAsFixed(3)} Nm',
                          ),
                          _valueCard(
                            controller.system.measuringMethod == 'SIGNAL' ? 'Signal' : 'Fastening Time',
                            controller.measurement?.toString() ?? '--',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: Container(
                        height: 300,
                        decoration: BoxDecoration(color: resultColor, borderRadius: BorderRadius.circular(16)),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('Result', style: TextStyle(color: Colors.white, fontSize: 28)),
                            const SizedBox(height: 24),
                            Text(
                              controller.result,
                              style: const TextStyle(color: Colors.white, fontSize: 70, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              controller.checksumOk == null
                                  ? ''
                                  : 'Checksum: ${controller.checksumOk! ? 'OK' : 'NG'}',
                              style: const TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _recentKittingScans(),
                const SizedBox(height: 10),
                _rawMonitor(),
                const SizedBox(height: 10),
                _history(),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _open(BuildContext context, Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
    if (mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _qrFocus.requestFocus());
    }
  }

  Widget _statusBar(BuildContext context) {
    final connected = controller.monitorConnected;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Icon(connected ? Icons.link : Icons.link_off, color: connected ? Colors.green : Colors.grey),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                connected
                    ? 'DTM45 connected (${controller.communication.monitorMode})'
                    : 'DTM45 not connected - open Communication setting',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            FilledButton(
              onPressed: () async {
                if (connected) {
                  await controller.disconnectMonitor();
                } else {
                  final ok = await controller.connectMonitor();
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Unable to connect. Check Communication setting and USB permission.')),
                    );
                  }
                }
              },
              child: Text(connected ? 'Disconnect' : 'Connect'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kittingCard() {
    final hasKitting = controller.currentKittingNumber.isNotEmpty;
    final pythonMode = controller.communication.kittingQrMode == 'PYTHON';
    final serverOk = controller.pythonServerConnected;

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 230,
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
                  decoration: BoxDecoration(
                    color: hasKitting ? const Color(0xFF007A3D) : const Color(0xFF6B7280),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.qr_code_2, color: Colors.white),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Process ${controller.communication.processNumber}\nKitting Number',
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 72),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      border: Border.all(color: hasKitting ? Colors.green : Colors.grey.shade400, width: 2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: SelectableText(
                      hasKitting ? controller.currentKittingNumber : '-- WAITING FOR KITTING QR --',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: hasKitting ? 30 : 22,
                        fontWeight: FontWeight.bold,
                        color: hasKitting ? Colors.black87 : Colors.grey.shade600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (pythonMode) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: serverOk ? Colors.green.shade50 : Colors.orange.shade50,
                  border: Border.all(color: serverOk ? Colors.green : Colors.orange),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(serverOk ? Icons.cloud_done : Icons.cloud_off, color: serverOk ? Colors.green : Colors.orange),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'QR Source: Python / Arduino (Process ${controller.communication.processNumber})\n'
                        '${controller.pythonQrStatus}'
                        '${controller.pythonQrLastReceivedAt == null ? '' : '  •  Last QR: ${controller.pythonQrLastReceivedAt!.toLocal().toString().split('.').first}'}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: controller.testPythonQrConnection,
                      icon: const Icon(Icons.sync),
                      label: const Text('Test / Sync'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      onPressed: () async => controller.clearKittingNumber(),
                      icon: const Icon(Icons.clear),
                      label: const Text('Clear'),
                    ),
                  ],
                ),
              ),
              if (controller.pythonQrLastError.isNotEmpty)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      controller.pythonQrLastError,
                      style: const TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Automatic mode: Process ${controller.communication.processNumber} Kitting QR → existing Python/Flask program → Wi-Fi/LAN → this tablet. '
                  'No manual Register button is required. Only the QR validated for this tablet’s assigned process becomes active.',
                  style: const TextStyle(color: Colors.grey),
                ),
              ),
            ] else ...[
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qrInput,
                      focusNode: _qrFocus,
                      autofocus: true,
                      textInputAction: TextInputAction.done,
                      onSubmitted: _submitKitting,
                      decoration: const InputDecoration(
                        labelText: 'Scan Kitting QR here (USB HID / keyboard mode)',
                        hintText: 'Scanner data appears here, then Enter registers it',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.qr_code_scanner),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: () => _submitKitting(_qrInput.text),
                    icon: const Icon(Icons.check),
                    label: const Text('Register'),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      _qrInput.clear();
                      await controller.clearKittingNumber();
                      _qrFocus.requestFocus();
                    },
                    icon: const Icon(Icons.clear),
                    label: const Text('Clear'),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Direct USB fallback: use USB HID keyboard mode with Enter/CR suffix.',
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _valueCard(String label, String value) {
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: Row(
        children: [
          Container(
            width: 230,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 21),
            decoration: const BoxDecoration(
              color: Color(0xFF003E92),
              borderRadius: BorderRadius.horizontal(left: Radius.circular(12)),
            ),
            child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 20)),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(value, textAlign: TextAlign.right, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _recentKittingScans() {
    return Card(
      child: ExpansionTile(
        leading: const Icon(Icons.qr_code_2),
        title: const Text('Recent Kitting QR scans', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(controller.kittingScans.isEmpty ? 'No Kitting QR scanned yet.' : 'Latest: ${controller.kittingScans.first.value}'),
        children: controller.kittingScans.isEmpty
            ? const [Padding(padding: EdgeInsets.all(16), child: Text('No Kitting QR scans yet.'))]
            : controller.kittingScans.take(10).map((scan) {
                return ListTile(
                  dense: true,
                  leading: const Icon(Icons.qr_code),
                  title: SelectableText(scan.value),
                  subtitle: Text('Process ${scan.processNumber}  •  ${scan.timestamp.toLocal().toString().split('.').first}'),
                );
              }).toList(),
      ),
    );
  }

  Widget _rawMonitor() {
    return Card(
      child: ExpansionTile(
        title: const Text('Raw RS-232 / Ethernet Monitor', style: TextStyle(fontWeight: FontWeight.bold)),
        childrenPadding: const EdgeInsets.all(12),
        children: [
          Container(
            width: double.infinity,
            height: 130,
            padding: const EdgeInsets.all(10),
            color: Colors.black87,
            child: SingleChildScrollView(
              reverse: true,
              child: SelectableText(
                controller.rawHex,
                style: const TextStyle(color: Colors.lightGreenAccent, fontFamily: 'monospace'),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: Text('CSV: ${controller.csvPath}', maxLines: 2, overflow: TextOverflow.ellipsis)),
              TextButton.icon(onPressed: controller.clearRaw, icon: const Icon(Icons.delete_outline), label: const Text('Clear')),
              OutlinedButton.icon(
                onPressed: () => controller.logger.openCsvFolder(),
                icon: const Icon(Icons.folder_open),
                label: const Text('Open Folder'),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: () => controller.logger.shareCurrent(),
                icon: const Icon(Icons.share),
                label: const Text('Share CSV'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _history() {
    return Card(
      child: ExpansionTile(
        title: const Text('Fastening history', style: TextStyle(fontWeight: FontWeight.bold)),
        children: controller.history.isEmpty
            ? const [Padding(padding: EdgeInsets.all(16), child: Text('No fastening records received yet.'))]
            : controller.history.take(20).map((r) {
                return ListTile(
                  dense: true,
                  leading: CircleAvatar(child: Text('${r.channel}')),
                  title: Text(
                    'P${r.processNumber}   Kitting ${r.kittingNumber.isEmpty ? '--' : r.kittingNumber}   Current ${r.convertedCurrent}   '
                    'Torque ${r.torque?.toStringAsFixed(3) ?? '--'} ${r.unit}   ${r.measuringMethod} ${r.measurement}   ${r.result}',
                  ),
                  subtitle: Text(r.timestamp.toLocal().toString()),
                );
              }).toList(),
      ),
    );
  }
}

class JudgmentSettingsPage extends StatefulWidget {
  const JudgmentSettingsPage({super.key, required this.controller});
  final DelvoController controller;

  @override
  State<JudgmentSettingsPage> createState() => _JudgmentSettingsPageState();
}

class _JudgmentSettingsPageState extends State<JudgmentSettingsPage> {
  int selected = 1;
  final factor = TextEditingController();
  final torqueUpper = TextEditingController();
  final torqueLower = TextEditingController();
  final signalUpper = TextEditingController();
  final signalLower = TextEditingController();

  DelvoController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final cfg = c.channels[selected]!;
    factor.text = cfg.torqueFactor.toStringAsFixed(10);
    torqueUpper.text = cfg.torqueUpper.toStringAsFixed(3);
    torqueLower.text = cfg.torqueLower.toStringAsFixed(3);
    signalUpper.text = cfg.signalUpper.toString();
    signalLower.text = cfg.signalLower.toString();
  }

  @override
  void dispose() {
    factor.dispose();
    torqueUpper.dispose();
    torqueLower.dispose();
    signalUpper.dispose();
    signalLower.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Judgement value setting')),
      body: AnimatedBuilder(
        animation: c,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: selected,
                            decoration: const InputDecoration(labelText: 'Select channel', border: OutlineInputBorder()),
                            items: (c.channels.keys.toList()..sort())
                                .map((ch) => DropdownMenuItem(value: ch, child: Text('CH$ch')))
                                .toList(),
                            onChanged: (v) {
                              if (v == null) return;
                              setState(() {
                                selected = v;
                                _load();
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: _field(factor, 'Torque conversion factor', decimal: true)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: _field(torqueUpper, 'Torque upper limit (Nm)', decimal: true)),
                        const SizedBox(width: 12),
                        Expanded(child: _field(torqueLower, 'Torque lower limit (Nm)', decimal: true)),
                        const SizedBox(width: 12),
                        Expanded(child: _field(signalUpper, '${c.system.measuringMethod} upper limit')),
                        const SizedBox(width: 12),
                        Expanded(child: _field(signalLower, '${c.system.measuringMethod} lower limit')),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerRight,
                      child: FilledButton.icon(
                        icon: const Icon(Icons.check),
                        label: const Text('Save CH settings'),
                        onPressed: () async {
                          final cfg = ChannelConfig(
                            channel: selected,
                            torqueFactor: double.tryParse(factor.text) ?? 9.99,
                            torqueUpper: double.tryParse(torqueUpper.text) ?? 8,
                            torqueLower: double.tryParse(torqueLower.text) ?? 0,
                            signalUpper: int.tryParse(signalUpper.text) ?? 60000,
                            signalLower: int.tryParse(signalLower.text) ?? 0,
                          );
                          await c.updateChannel(cfg);
                          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Channel settings saved.')));
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Channel')),
                    DataColumn(label: Text('T.C. factor')),
                    DataColumn(label: Text('Updated')),
                    DataColumn(label: Text('Torque UL')),
                    DataColumn(label: Text('Torque LL')),
                    DataColumn(label: Text('Measurement UL')),
                    DataColumn(label: Text('Measurement LL')),
                  ],
                  rows: (c.channels.values.toList()..sort((a, b) => a.channel.compareTo(b.channel))).map((cfg) {
                    return DataRow(cells: [
                      DataCell(Text('CH${cfg.channel}')),
                      DataCell(Text(cfg.torqueFactor.toStringAsFixed(10))),
                      DataCell(Text(cfg.updatedAt?.toLocal().toString().split('.').first ?? '')),
                      DataCell(Text(cfg.torqueUpper.toStringAsFixed(3))),
                      DataCell(Text(cfg.torqueLower.toStringAsFixed(3))),
                      DataCell(Text('${cfg.signalUpper}')),
                      DataCell(Text('${cfg.signalLower}')),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, {bool decimal = false}) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.numberWithOptions(decimal: decimal, signed: true),
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}

class TorqueConversionPage extends StatefulWidget {
  const TorqueConversionPage({super.key, required this.controller});
  final DelvoController controller;

  @override
  State<TorqueConversionPage> createState() => _TorqueConversionPageState();
}

class _TorqueConversionPageState extends State<TorqueConversionPage> {
  DelvoController get c => widget.controller;
  final manualTorque = TextEditingController();

  @override
  void initState() {
    super.initState();
    c.torqueConversionActive = true;
  }

  @override
  void dispose() {
    c.torqueConversionActive = false;
    manualTorque.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Torque conversion')),
      body: AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final avgTorque = c.trialAverageTorque;
          final avgCurrent = c.trialAverageCurrent;
          final factor = c.calculatedTorqueFactor;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(child: _metric('Operation channel', c.latestMonitorPacket?.channel.toString() ?? '--')),
                      Expanded(child: _metric('Trial', '${c.torqueTrials.length} / ${c.system.trialCount}')),
                      Expanded(child: _metric('Measured Value (Torque Checker)', c.latestCheckerTorque?.toStringAsFixed(3) ?? '--')),
                      Expanded(child: _metric('Current Value (Converted)', c.latestMonitorPacket?.convertedCurrent.toString() ?? '--')),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Icon(c.checkerConnected ? Icons.usb : Icons.usb_off, color: c.checkerConnected ? Colors.green : Colors.grey),
                      const SizedBox(width: 8),
                      Expanded(child: Text(c.checkerConnected ? 'Torque Checker connected' : 'Torque Checker not connected')),
                      FilledButton(
                        onPressed: () async {
                          if (c.checkerConnected) {
                            await c.disconnectChecker();
                          } else {
                            final ok = await c.connectChecker();
                            if (!ok && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to connect Torque Checker. Configure its USB device first.')));
                            }
                          }
                        },
                        child: Text(c.checkerConnected ? 'Disconnect' : 'Connect Checker'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: manualTorque,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                          decoration: InputDecoration(
                            labelText: 'Manual Torque Checker value (${c.system.torqueCheckerUnit})',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      FilledButton.icon(
                        onPressed: () {
                          final v = double.tryParse(manualTorque.text);
                          if (v == null || !c.addManualTorqueTrial(v)) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Enter a valid torque and make sure a DTM45 packet has already been received.')),
                            );
                          } else {
                            manualTorque.clear();
                          }
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('Add trial manually'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: const [
                      DataColumn(label: Text('Number')),
                      DataColumn(label: Text('Measured Value (Torque Checker)')),
                      DataColumn(label: Text('Current Value (Converted)')),
                      DataColumn(label: Text('Timestamp')),
                      DataColumn(label: Text('Action')),
                    ],
                    rows: c.torqueTrials.asMap().entries.map((entry) {
                      final index = entry.key;
                      final t = entry.value;
                      return DataRow(cells: [
                          DataCell(Text('${t.number}')),
                          DataCell(Text(t.measuredTorque.toStringAsFixed(3))),
                          DataCell(Text('${t.convertedCurrent}')),
                          DataCell(Text(t.timestamp.toLocal().toString().split('.').first)),
                          DataCell(IconButton(
                            tooltip: 'Delete trial',
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => c.deleteTorqueTrial(index),
                          )),
                        ]);
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(child: _metric('Average Torque', avgTorque?.toStringAsFixed(3) ?? '--')),
                      Expanded(child: _metric('Average Current', avgCurrent?.toStringAsFixed(0) ?? '--')),
                      Expanded(child: _metric('T.C. factor', factor?.toStringAsFixed(10) ?? '--')),
                      OutlinedButton.icon(onPressed: c.clearTorqueTrials, icon: const Icon(Icons.delete_outline), label: const Text('Clear')),
                      const SizedBox(width: 8),
                      FilledButton.icon(
                        onPressed: factor == null
                            ? null
                            : () async {
                                final ok = await c.applyTorqueFactor();
                                if (context.mounted && ok) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('T.C. factor applied to the operation channel.')));
                              },
                        icon: const Icon(Icons.upload_file),
                        label: const Text('Apply T.C. factor'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Automatic pairing is active on this screen. A Torque Checker value and DTM45 converted-current packet received within 8 seconds are stored as one trial. '
                'The conversion factor is the average of each trial ratio: Measured Torque ÷ Converted Current. This matches the Windows monitor calculation.',
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _metric(String label, String value) => Padding(
        padding: const EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
        ]),
      );
}

class CommunicationPage extends StatefulWidget {
  const CommunicationPage({super.key, required this.controller});
  final DelvoController controller;

  @override
  State<CommunicationPage> createState() => _CommunicationPageState();
}

class _CommunicationPageState extends State<CommunicationPage> {
  late CommunicationConfig cfg;
  late TextEditingController ip;
  late TextEditingController port;
  late TextEditingController pythonUrl;
  late TextEditingController pythonPoll;

  DelvoController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    cfg = c.communication;
    ip = TextEditingController(text: cfg.standbyIp);
    port = TextEditingController(text: '${cfg.standbyPort}');
    pythonUrl = TextEditingController(text: cfg.pythonServerUrl);
    pythonPoll = TextEditingController(text: '${cfg.pythonPollMs}');
    c.refreshUsbDevices();
  }

  @override
  void dispose() {
    ip.dispose();
    port.dispose();
    pythonUrl.dispose();
    pythonPoll.dispose();
    super.dispose();
  }

  CommunicationConfig _collectConfig() {
    return cfg.copyWith(
      standbyIp: ip.text.trim(),
      standbyPort: int.tryParse(port.text) ?? 51001,
      pythonServerUrl: pythonUrl.text.trim(),
      pythonPollMs: (int.tryParse(pythonPoll.text) ?? 500).clamp(250, 5000).toInt(),
    );
  }

  Future<void> _saveAll() async {
    cfg = _collectConfig();
    await c.updateCommunication(cfg);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Communication settings saved.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Communication setting')),
      body: AnimatedBuilder(
        animation: c,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Screw fastening monitor / DTM45', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'RS232', label: Text('RS-232C'), icon: Icon(Icons.usb)),
                        ButtonSegment(value: 'ETHERNET', label: Text('Ethernet'), icon: Icon(Icons.lan)),
                      ],
                      selected: {cfg.monitorMode},
                      onSelectionChanged: (s) => setState(() => cfg = cfg.copyWith(monitorMode: s.first)),
                    ),
                    const SizedBox(height: 12),
                    if (cfg.monitorMode == 'RS232') ...[
                      _deviceDrop('DTM45 USB device', c.monitorDevice, c.selectMonitorDevice),
                      const SizedBox(height: 10),
                      _serialEditor(cfg.monitorSerial, (v) => setState(() => cfg = cfg.copyWith(monitorSerial: v))),
                    ] else ...[
                      SegmentedButton<String>(
                        segments: const [ButtonSegment(value: 'SERVER', label: Text('Server')), ButtonSegment(value: 'CLIENT', label: Text('Client'))],
                        selected: {cfg.ethernetRole},
                        onSelectionChanged: (s) => setState(() => cfg = cfg.copyWith(ethernetRole: s.first)),
                      ),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: TextField(controller: ip, decoration: const InputDecoration(labelText: 'Standby IP', border: OutlineInputBorder()))),
                        const SizedBox(width: 12),
                        Expanded(child: TextField(controller: port, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Standby port', border: OutlineInputBorder()))),
                      ]),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        FilledButton.icon(
                          icon: const Icon(Icons.save),
                          label: const Text('Save DTM45 communication'),
                          onPressed: _saveAll,
                        ),
                        const SizedBox(width: 10),
                        FilledButton(
                          onPressed: () async {
                            cfg = _collectConfig();
                            await c.updateCommunication(cfg);
                            c.monitorConnected ? await c.disconnectMonitor() : await c.connectMonitor();
                          },
                          child: Text(c.monitorConnected ? 'Disconnect DTM45' : 'Connect DTM45'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Torque Checker', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    _deviceDrop('Torque Checker USB device', c.checkerDevice, c.selectCheckerDevice),
                    const SizedBox(height: 10),
                    _serialEditor(cfg.checkerSerial, (v) => setState(() => cfg = cfg.copyWith(checkerSerial: v))),
                    const SizedBox(height: 12),
                    Row(children: [
                      FilledButton.icon(
                        onPressed: _saveAll,
                        icon: const Icon(Icons.save),
                        label: const Text('Save Checker communication'),
                      ),
                      const SizedBox(width: 10),
                      FilledButton(
                        onPressed: () async {
                          cfg = _collectConfig();
                          await c.updateCommunication(cfg);
                          c.checkerConnected ? await c.disconnectChecker() : await c.connectChecker();
                        },
                        child: Text(c.checkerConnected ? 'Disconnect Checker' : 'Connect Checker'),
                      ),
                    ]),
                    const SizedBox(height: 8),
                    const Text('For simultaneous DTM45 + Torque Checker USB communication, use a powered USB-C OTG hub if the tablet has only one USB-C port.'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Kitting QR Reader / Python Bridge', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'PYTHON', label: Text('Python / Arduino'), icon: Icon(Icons.lan)),
                        ButtonSegment(value: 'HID', label: Text('Direct USB HID'), icon: Icon(Icons.keyboard_alt_outlined)),
                      ],
                      selected: {cfg.kittingQrMode},
                      onSelectionChanged: (s) => setState(() => cfg = cfg.copyWith(kittingQrMode: s.first)),
                    ),
                    const SizedBox(height: 14),
                    if (cfg.kittingQrMode == 'PYTHON') ...[
                      TextField(
                        controller: pythonUrl,
                        keyboardType: TextInputType.url,
                        decoration: const InputDecoration(
                          labelText: 'Python Flask server URL',
                          hintText: 'Example: http://192.168.3.220:5001',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.computer),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<int>(
                              value: cfg.processNumber,
                              decoration: const InputDecoration(
                                labelText: 'This tablet is assigned to',
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.precision_manufacturing),
                              ),
                              items: List.generate(9, (index) {
                                final processNo = index + 1;
                                return DropdownMenuItem(
                                  value: processNo,
                                  child: Text('Process $processNo'),
                                );
                              }),
                              onChanged: (v) {
                                if (v != null) setState(() => cfg = cfg.copyWith(processNumber: v));
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          SizedBox(
                            width: 190,
                            child: TextField(
                              controller: pythonPoll,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Polling interval (ms)',
                                hintText: '500',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          FilledButton.icon(
                            onPressed: _saveAll,
                            icon: const Icon(Icons.save),
                            label: const Text('Save QR bridge'),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: () async {
                              cfg = _collectConfig();
                              await c.updateCommunication(cfg);
                              final ok = await c.testPythonQrConnection();
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(ok ? 'Python QR bridge connected.' : 'Cannot connect to Python QR bridge.')),
                                );
                              }
                            },
                            icon: const Icon(Icons.sync),
                            label: const Text('Test connection'),
                          ),
                          const SizedBox(width: 16),
                          Icon(c.pythonServerConnected ? Icons.check_circle : Icons.cancel,
                              color: c.pythonServerConnected ? Colors.green : Colors.red),
                          const SizedBox(width: 6),
                          Expanded(child: Text(c.pythonQrStatus)),
                        ],
                      ),
                      if (c.pythonQrLastError.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(c.pythonQrLastError, style: const TextStyle(color: Colors.red, fontSize: 12)),
                      ],
                      const SizedBox(height: 10),
                      const Text(
                        'Use the same APK for Process 1 through Process 9. Select this tablet’s process above. '
                        'The Windows Python program publishes only the validated Kitting QR for that process, and this tablet reads it through Wi-Fi/LAN. '
                        'Existing R35D-B / Arduino scanner OFF and interlock behavior remains controlled by your current system.',
                      ),
                    ] else ...[
                      const ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(Icons.keyboard_alt_outlined, color: Colors.green),
                        title: Text('Direct USB HID / Keyboard mode'),
                        subtitle: Text('Use only as a fallback. Connect the scanner directly to the tablet and configure Enter/CR suffix.'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _deviceDrop(String label, UsbDevice? value, ValueChanged<UsbDevice?> onChanged) {
    return DropdownButtonFormField<UsbDevice>(
      value: value != null && c.usbDevices.any((d) => d.deviceId == value.deviceId) ? value : null,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      items: c.usbDevices.map((d) => DropdownMenuItem(value: d, child: Text(c.deviceLabel(d)))).toList(),
      onChanged: onChanged,
    );
  }

  Widget _serialEditor(SerialConfig s, ValueChanged<SerialConfig> changed) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        _drop<int>('Baud rate', s.baudRate, const [9600, 19200, 38400, 57600, 115200], (v) => changed(s.copyWith(baudRate: v))),
        _drop<int>('Data bit', s.dataBits, const [7, 8], (v) => changed(s.copyWith(dataBits: v))),
        _drop<int>('Parity bit', s.parity, const [UsbPort.PARITY_NONE, UsbPort.PARITY_ODD, UsbPort.PARITY_EVEN], (v) => changed(s.copyWith(parity: v)), label: (v) => v == UsbPort.PARITY_NONE ? 'none' : v == UsbPort.PARITY_ODD ? 'odd' : 'even'),
        _drop<int>('Stop bit', s.stopBits, const [1, 2], (v) => changed(s.copyWith(stopBits: v)), label: (v) => '${v}bit'),
      ],
    );
  }

  Widget _drop<T>(String title, T value, List<T> values, ValueChanged<T> onChanged, {String Function(T)? label}) {
    return SizedBox(
      width: 180,
      child: DropdownButtonFormField<T>(
        value: value,
        decoration: InputDecoration(labelText: title, border: const OutlineInputBorder()),
        items: values.map((v) => DropdownMenuItem(value: v, child: Text(label?.call(v) ?? '$v'))).toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      ),
    );
  }
}

class SystemSettingsPage extends StatefulWidget {
  const SystemSettingsPage({super.key, required this.controller});
  final DelvoController controller;

  @override
  State<SystemSettingsPage> createState() => _SystemSettingsPageState();
}

class _SystemSettingsPageState extends State<SystemSettingsPage> {
  late SystemConfig cfg;
  late TextEditingController name;
  late TextEditingController trials;
  late TextEditingController rangeMin;
  late TextEditingController rangeMax;

  DelvoController get c => widget.controller;

  @override
  void initState() {
    super.initState();
    cfg = c.system;
    name = TextEditingController(text: cfg.deviceName);
    trials = TextEditingController(text: '${cfg.trialCount}');
    rangeMin = TextEditingController(text: '${cfg.effectiveMin}');
    rangeMax = TextEditingController(text: '${cfg.effectiveMax}');
  }

  @override
  void dispose() {
    name.dispose();
    trials.dispose();
    rangeMin.dispose();
    rangeMax.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('System Setting')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'Device name', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: cfg.language,
                    decoration: const InputDecoration(labelText: 'Language setting', border: OutlineInputBorder()),
                    items: const ['English'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => cfg = cfg.copyWith(language: v)),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: trials,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Number of trials for Torque conversion factor measurement', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    value: cfg.autoLog,
                    title: const Text('Fastening Data Log file automatic output'),
                    subtitle: Text('CSV location: ${c.csvPath}'),
                    onChanged: (v) => setState(() => cfg = cfg.copyWith(autoLog: v)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField<String>(
                    value: cfg.torqueCheckerUnit,
                    decoration: const InputDecoration(labelText: 'Torque checker unit', border: OutlineInputBorder()),
                    items: const ['Nm', 'Ncm', 'kgf·cm'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => cfg = cfg.copyWith(torqueCheckerUnit: v)),
                  ),
                  const SizedBox(height: 12),
                  const Text('Effective range'),
                  const SizedBox(height: 6),
                  Row(children: [
                    Expanded(child: TextField(controller: rangeMin, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'Minimum', border: OutlineInputBorder()))),
                    const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('~')),
                    Expanded(child: TextField(controller: rangeMax, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'Maximum', border: OutlineInputBorder()))),
                  ]),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: cfg.measuringMethod,
                    decoration: const InputDecoration(labelText: 'Measuring method', border: OutlineInputBorder()),
                    items: const ['SIGNAL', 'TIME'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => cfg = cfg.copyWith(measuringMethod: v)),
                  ),
                  const SizedBox(height: 8),
                  const Text('The measuring-method selection is intended for DTM45 operation, matching the Windows monitor setting.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: () async {
                cfg = cfg.copyWith(
                  deviceName: name.text.trim().isEmpty ? 'EM Fastening' : name.text.trim(),
                  trialCount: int.tryParse(trials.text) ?? 10,
                  effectiveMin: double.tryParse(rangeMin.text) ?? -8,
                  effectiveMax: double.tryParse(rangeMax.text) ?? 8,
                );
                await c.updateSystem(cfg);
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('System settings saved.')));
              },
              icon: const Icon(Icons.check),
              label: const Text('Save System Setting'),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Android build: DELVO Tablet Monitor v0.5.0 - Process 1-9 QR Bridge'),
        ],
      ),
    );
  }
}
