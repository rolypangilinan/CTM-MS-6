import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class PreferencesService {
  static const _systemKey = 'system_config_v2';
  static const _commKey = 'communication_config_v2';
  static const _channelsKey = 'channel_configs_v2';
  static const _kittingKey = 'current_kitting_number_v1';

  Future<String> loadCurrentKittingNumber() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kittingKey) ?? '';
  }

  Future<void> saveCurrentKittingNumber(String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kittingKey, value);
  }

  Future<SystemConfig> loadSystem() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(_systemKey);
    if (s == null) return const SystemConfig();
    try {
      return SystemConfig.fromJson(Map<String, dynamic>.from(jsonDecode(s) as Map));
    } catch (_) {
      return const SystemConfig();
    }
  }

  Future<void> saveSystem(SystemConfig c) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_systemKey, jsonEncode(c.toJson()));
  }

  Future<CommunicationConfig> loadCommunication() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(_commKey);
    if (s == null) return const CommunicationConfig();
    try {
      return CommunicationConfig.fromJson(Map<String, dynamic>.from(jsonDecode(s) as Map));
    } catch (_) {
      return const CommunicationConfig();
    }
  }

  Future<void> saveCommunication(CommunicationConfig c) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_commKey, jsonEncode(c.toJson()));
  }

  Future<Map<int, ChannelConfig>> loadChannels() async {
    final defaults = <int, ChannelConfig>{};
    for (var ch = 1; ch <= 14; ch++) {
      defaults[ch] = ChannelConfig(
        channel: ch,
        torqueFactor: ch == 1 ? 0.0048372085 : 9.99,
        torqueUpper: 8.0,
        torqueLower: ch == 1 ? 1.0 : 0.0,
        signalUpper: 60000,
        signalLower: 0,
        updatedAt: ch == 1 ? DateTime(2026, 9, 28, 13, 28, 20) : null,
      );
    }

    final p = await SharedPreferences.getInstance();
    final s = p.getString(_channelsKey);
    if (s == null) return defaults;
    try {
      final list = jsonDecode(s) as List;
      for (final item in list) {
        final c = ChannelConfig.fromJson(Map<String, dynamic>.from(item as Map));
        defaults[c.channel] = c;
      }
    } catch (_) {}
    return defaults;
  }

  Future<void> saveChannels(Map<int, ChannelConfig> channels) async {
    final p = await SharedPreferences.getInstance();
    final list = channels.values.toList()..sort((a, b) => a.channel.compareTo(b.channel));
    await p.setString(_channelsKey, jsonEncode(list.map((e) => e.toJson()).toList()));
  }
}
