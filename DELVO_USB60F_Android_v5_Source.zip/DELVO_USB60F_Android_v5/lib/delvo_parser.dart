import 'models.dart';

class DelvoParser {
  /// Confirmed DTM45 frame from the real equipment:
  /// CH1:1624-2456,<SUM><CR><LF>
  /// The checksum is one binary byte after the comma. CR/LF is removed before
  /// this method is called.
  Dtm45Packet? parseLine(String line) {
    if (line.isEmpty) return null;
    final codes = line.codeUnits.map((e) => e & 0xFF).toList();
    if (codes.length < 8) return null;

    final comma = codes.lastIndexOf(0x2C);
    if (comma < 0 || comma + 1 >= codes.length) return null;
    final payload = String.fromCharCodes(codes.sublist(0, comma));
    final m = RegExp(r'^CH(\d+):(\d+)-(\d+)$').firstMatch(payload);
    if (m == null) return null;

    final checksumReceived = codes[comma + 1];
    var sum = 0;
    for (final b in codes.sublist(0, comma + 1)) {
      sum = (sum + b) & 0xFF;
    }

    return Dtm45Packet(
      channel: int.parse(m.group(1)!),
      convertedCurrent: int.parse(m.group(2)!),
      measurement: int.parse(m.group(3)!),
      checksumOk: sum == checksumReceived,
      raw: line,
    );
  }
}

class TorqueCheckerParser {
  /// The Windows monitor showed Torque Checker output like:
  /// "9/28/2026 1:25:05 PM   + 7.79 N*m".
  /// This parser intentionally accepts common signed decimal formats.
  double? parseLine(String line) {
    final matches = RegExp(r'([+-]?\s*\d+(?:\.\d+)?)').allMatches(line).toList();
    if (matches.isEmpty) return null;
    // Prefer the last number because timestamps may also be present.
    final value = matches.last.group(1)!.replaceAll(' ', '');
    return double.tryParse(value);
  }
}
