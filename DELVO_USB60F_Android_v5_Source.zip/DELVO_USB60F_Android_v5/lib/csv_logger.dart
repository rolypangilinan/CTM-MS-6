import 'dart:io';

import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'models.dart';

class CsvLogger {
  static const header =
      'Timestamp,Process,KittingNumber,Channel,ConvertedCurrent,TCFactor,Torque,Unit,Measurement,MeasuringMethod,Result,Checksum,Raw\n';

  static const MethodChannel _storageChannel =
      MethodChannel('com.hiblow.delvo_usb60f/storage');

  File? _file;
  String? _fileName;
  String? _publicPath;
  bool _publicInitialized = false;

  String _dailyFileName() {
    final now = DateTime.now();
    final stamp =
        '${now.year.toString().padLeft(4, '0')}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
    return 'TighteningHistory_Process_Kitting_$stamp.csv';
  }

  Future<File> ensureFile() async {
    final desiredName = _dailyFileName();

    // Start a new file automatically when the calendar date changes.
    if (_file != null && _fileName == desiredName) {
      await _ensurePublicCopy(_file!);
      return _file!;
    }

    final dir = await getExternalStorageDirectory() ??
        await getApplicationDocumentsDirectory();
    final logDir = Directory('${dir.path}/DELVO');
    await logDir.create(recursive: true);

    final file = File('${logDir.path}/$desiredName');
    if (!await file.exists()) {
      await file.writeAsString(header, flush: true);
    }

    _file = file;
    _fileName = desiredName;
    _publicInitialized = false;
    _publicPath = null;

    // Keep an app-private backup, but also publish the same CSV into the
    // tablet's normal Downloads/DELVO folder so it is visible in My Files.
    await _ensurePublicCopy(file);
    return file;
  }

  Future<void> _ensurePublicCopy(File file) async {
    if (_publicInitialized) return;
    final name = _fileName ?? _dailyFileName();
    try {
      final content = await file.readAsString();
      _publicPath = await _storageChannel.invokeMethod<String>(
        'writeCsvPublic',
        {'fileName': name, 'content': content},
      );
      _publicInitialized = true;
    } on PlatformException {
      // The private backup remains available even if public storage fails.
      _publicPath ??= file.path;
    } on MissingPluginException {
      _publicPath ??= file.path;
    }
  }

  Future<void> append(FasteningRecord record) async {
    final file = await ensureFile();
    final row = '${record.csvRow}\n';

    // Always maintain the private backup first.
    await file.writeAsString(row, mode: FileMode.append, flush: true);

    // Mirror each new record to Internal storage/Download/DELVO.
    try {
      final name = _fileName ?? _dailyFileName();
      _publicPath = await _storageChannel.invokeMethod<String>(
        'appendCsvPublic',
        {
          'fileName': name,
          'header': header,
          'content': row,
        },
      );
      _publicInitialized = true;
    } on PlatformException {
      // Do not stop fastening logging if public storage is temporarily
      // unavailable; the private backup still contains the record.
    } on MissingPluginException {
      // Same fallback for desktop/test execution.
    }
  }

  Future<String> currentPath() async {
    final file = await ensureFile();
    return _publicPath ?? file.path;
  }

  Future<void> openCsvFolder() async {
    try {
      await _storageChannel.invokeMethod<void>('openDownloads');
    } on PlatformException {
      // No-op: Share CSV can still be used as a fallback.
    } on MissingPluginException {
      // No-op outside Android.
    }
  }

  Future<void> shareCurrent() async {
    final file = await ensureFile();
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path)],
        subject: 'DELVO tightening history',
        text: 'DELVO tightening history CSV',
      ),
    );
  }
}
