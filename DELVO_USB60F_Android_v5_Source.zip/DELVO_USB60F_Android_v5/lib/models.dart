import 'package:usb_serial/usb_serial.dart';

class SerialConfig {
  const SerialConfig({
    this.baudRate = 19200,
    this.dataBits = 8,
    this.stopBits = 1,
    this.parity = UsbPort.PARITY_NONE,
  });

  final int baudRate;
  final int dataBits;
  final int stopBits;
  final int parity;

  SerialConfig copyWith({int? baudRate, int? dataBits, int? stopBits, int? parity}) =>
      SerialConfig(
        baudRate: baudRate ?? this.baudRate,
        dataBits: dataBits ?? this.dataBits,
        stopBits: stopBits ?? this.stopBits,
        parity: parity ?? this.parity,
      );

  Map<String, dynamic> toJson() => {
        'baudRate': baudRate,
        'dataBits': dataBits,
        'stopBits': stopBits,
        'parity': parity,
      };

  factory SerialConfig.fromJson(Map<String, dynamic> j) => SerialConfig(
        baudRate: (j['baudRate'] as num?)?.toInt() ?? 19200,
        dataBits: (j['dataBits'] as num?)?.toInt() ?? 8,
        stopBits: (j['stopBits'] as num?)?.toInt() ?? 1,
        parity: (j['parity'] as num?)?.toInt() ?? UsbPort.PARITY_NONE,
      );
}

class ChannelConfig {
  const ChannelConfig({
    required this.channel,
    required this.torqueFactor,
    required this.torqueUpper,
    required this.torqueLower,
    required this.signalUpper,
    required this.signalLower,
    this.updatedAt,
  });

  final int channel;
  final double torqueFactor;
  final double torqueUpper;
  final double torqueLower;
  final int signalUpper;
  final int signalLower;
  final DateTime? updatedAt;

  bool get factorConfigured => torqueFactor > 0 && (torqueFactor - 9.99).abs() > 0.000001;

  ChannelConfig copyWith({
    double? torqueFactor,
    double? torqueUpper,
    double? torqueLower,
    int? signalUpper,
    int? signalLower,
    DateTime? updatedAt,
  }) =>
      ChannelConfig(
        channel: channel,
        torqueFactor: torqueFactor ?? this.torqueFactor,
        torqueUpper: torqueUpper ?? this.torqueUpper,
        torqueLower: torqueLower ?? this.torqueLower,
        signalUpper: signalUpper ?? this.signalUpper,
        signalLower: signalLower ?? this.signalLower,
        updatedAt: updatedAt ?? this.updatedAt,
      );

  Map<String, dynamic> toJson() => {
        'channel': channel,
        'torqueFactor': torqueFactor,
        'torqueUpper': torqueUpper,
        'torqueLower': torqueLower,
        'signalUpper': signalUpper,
        'signalLower': signalLower,
        'updatedAt': updatedAt?.toIso8601String(),
      };

  factory ChannelConfig.fromJson(Map<String, dynamic> j) => ChannelConfig(
        channel: (j['channel'] as num).toInt(),
        torqueFactor: (j['torqueFactor'] as num?)?.toDouble() ?? 9.99,
        torqueUpper: (j['torqueUpper'] as num?)?.toDouble() ?? 8.0,
        torqueLower: (j['torqueLower'] as num?)?.toDouble() ?? 0.0,
        signalUpper: (j['signalUpper'] as num?)?.toInt() ?? 60000,
        signalLower: (j['signalLower'] as num?)?.toInt() ?? 0,
        updatedAt: j['updatedAt'] == null ? null : DateTime.tryParse(j['updatedAt'].toString()),
      );
}

class SystemConfig {
  const SystemConfig({
    this.deviceName = 'EM Fastening',
    this.language = 'English',
    this.trialCount = 10,
    this.autoLog = true,
    this.torqueCheckerUnit = 'Nm',
    this.effectiveMin = -8.0,
    this.effectiveMax = 8.0,
    this.measuringMethod = 'SIGNAL',
  });

  final String deviceName;
  final String language;
  final int trialCount;
  final bool autoLog;
  final String torqueCheckerUnit;
  final double effectiveMin;
  final double effectiveMax;
  final String measuringMethod;

  SystemConfig copyWith({
    String? deviceName,
    String? language,
    int? trialCount,
    bool? autoLog,
    String? torqueCheckerUnit,
    double? effectiveMin,
    double? effectiveMax,
    String? measuringMethod,
  }) =>
      SystemConfig(
        deviceName: deviceName ?? this.deviceName,
        language: language ?? this.language,
        trialCount: trialCount ?? this.trialCount,
        autoLog: autoLog ?? this.autoLog,
        torqueCheckerUnit: torqueCheckerUnit ?? this.torqueCheckerUnit,
        effectiveMin: effectiveMin ?? this.effectiveMin,
        effectiveMax: effectiveMax ?? this.effectiveMax,
        measuringMethod: measuringMethod ?? this.measuringMethod,
      );

  Map<String, dynamic> toJson() => {
        'deviceName': deviceName,
        'language': language,
        'trialCount': trialCount,
        'autoLog': autoLog,
        'torqueCheckerUnit': torqueCheckerUnit,
        'effectiveMin': effectiveMin,
        'effectiveMax': effectiveMax,
        'measuringMethod': measuringMethod,
      };

  factory SystemConfig.fromJson(Map<String, dynamic> j) => SystemConfig(
        deviceName: j['deviceName']?.toString() ?? 'EM Fastening',
        language: j['language']?.toString() ?? 'English',
        trialCount: (j['trialCount'] as num?)?.toInt() ?? 10,
        autoLog: j['autoLog'] as bool? ?? true,
        torqueCheckerUnit: j['torqueCheckerUnit']?.toString() ?? 'Nm',
        effectiveMin: (j['effectiveMin'] as num?)?.toDouble() ?? -8.0,
        effectiveMax: (j['effectiveMax'] as num?)?.toDouble() ?? 8.0,
        measuringMethod: j['measuringMethod']?.toString() ?? 'SIGNAL',
      );
}

class CommunicationConfig {
  const CommunicationConfig({
    this.monitorMode = 'RS232',
    this.ethernetRole = 'SERVER',
    this.standbyIp = '192.168.210.1',
    this.standbyPort = 51001,
    this.monitorSerial = const SerialConfig(),
    this.checkerSerial = const SerialConfig(),
    this.kittingQrMode = 'PYTHON',
    this.pythonServerUrl = 'http://192.168.3.220:5001',
    this.processNumber = 1,
    this.pythonPollMs = 500,
  });

  final String monitorMode;
  final String ethernetRole;
  final String standbyIp;
  final int standbyPort;
  final SerialConfig monitorSerial;
  final SerialConfig checkerSerial;

  // Kitting QR source:
  // PYTHON = receive the process-specific QR from the existing Flask/Arduino
  //          system over LAN/Wi-Fi. The same APK can be assigned to P1..P9.
  // HID    = direct USB keyboard scanner connected to the tablet.
  final String kittingQrMode;
  final String pythonServerUrl;
  final int processNumber;
  final int pythonPollMs;

  CommunicationConfig copyWith({
    String? monitorMode,
    String? ethernetRole,
    String? standbyIp,
    int? standbyPort,
    SerialConfig? monitorSerial,
    SerialConfig? checkerSerial,
    String? kittingQrMode,
    String? pythonServerUrl,
    int? processNumber,
    int? pythonPollMs,
  }) =>
      CommunicationConfig(
        monitorMode: monitorMode ?? this.monitorMode,
        ethernetRole: ethernetRole ?? this.ethernetRole,
        standbyIp: standbyIp ?? this.standbyIp,
        standbyPort: standbyPort ?? this.standbyPort,
        monitorSerial: monitorSerial ?? this.monitorSerial,
        checkerSerial: checkerSerial ?? this.checkerSerial,
        kittingQrMode: kittingQrMode ?? this.kittingQrMode,
        pythonServerUrl: pythonServerUrl ?? this.pythonServerUrl,
        processNumber: processNumber ?? this.processNumber,
        pythonPollMs: pythonPollMs ?? this.pythonPollMs,
      );

  Map<String, dynamic> toJson() => {
        'monitorMode': monitorMode,
        'ethernetRole': ethernetRole,
        'standbyIp': standbyIp,
        'standbyPort': standbyPort,
        'monitorSerial': monitorSerial.toJson(),
        'checkerSerial': checkerSerial.toJson(),
        'kittingQrMode': kittingQrMode,
        'pythonServerUrl': pythonServerUrl,
        'processNumber': processNumber,
        'pythonPollMs': pythonPollMs,
      };

  factory CommunicationConfig.fromJson(Map<String, dynamic> j) {
    // Migration from v0.4.0: old builds stored pythonQrSource='p1' or 'ms'.
    // A missing processNumber therefore safely defaults to Process 1.
    var process = (j['processNumber'] as num?)?.toInt() ?? 1;
    if (process < 1 || process > 9) process = 1;
    return CommunicationConfig(
      monitorMode: j['monitorMode']?.toString() ?? 'RS232',
      ethernetRole: j['ethernetRole']?.toString() ?? 'SERVER',
      standbyIp: j['standbyIp']?.toString() ?? '192.168.210.1',
      standbyPort: (j['standbyPort'] as num?)?.toInt() ?? 51001,
      monitorSerial: SerialConfig.fromJson(Map<String, dynamic>.from(j['monitorSerial'] as Map? ?? {})),
      checkerSerial: SerialConfig.fromJson(Map<String, dynamic>.from(j['checkerSerial'] as Map? ?? {})),
      kittingQrMode: j['kittingQrMode']?.toString() ?? 'PYTHON',
      pythonServerUrl: j['pythonServerUrl']?.toString() ?? 'http://192.168.3.220:5001',
      processNumber: process,
      pythonPollMs: (j['pythonPollMs'] as num?)?.toInt() ?? 500,
    );
  }
}

class Dtm45Packet {
  const Dtm45Packet({
    required this.channel,
    required this.convertedCurrent,
    required this.measurement,
    required this.checksumOk,
    required this.raw,
  });

  final int channel;
  final int convertedCurrent;
  final int measurement;
  final bool checksumOk;
  final String raw;
}

class TorqueTrial {
  const TorqueTrial({
    required this.number,
    required this.channel,
    required this.measuredTorque,
    required this.convertedCurrent,
    required this.timestamp,
  });

  final int number;
  final int channel;
  final double measuredTorque;
  final int convertedCurrent;
  final DateTime timestamp;
}

class KittingScan {
  const KittingScan({required this.value, required this.timestamp, required this.processNumber});

  final String value;
  final DateTime timestamp;
  final int processNumber;
}

class FasteningRecord {
  FasteningRecord({
    required this.timestamp,
    required this.processNumber,
    required this.kittingNumber,
    required this.channel,
    required this.convertedCurrent,
    required this.torqueFactor,
    required this.torque,
    required this.unit,
    required this.measurement,
    required this.measuringMethod,
    required this.result,
    required this.checksumOk,
    required this.raw,
  });

  final DateTime timestamp;
  final int processNumber;
  final String kittingNumber;
  final int channel;
  final int convertedCurrent;
  final double? torqueFactor;
  final double? torque;
  final String unit;
  final int measurement;
  final String measuringMethod;
  final String result;
  final bool checksumOk;
  final String raw;

  String get csvRow => [
        timestamp.toIso8601String(),
        processNumber,
        _escape(kittingNumber),
        channel,
        convertedCurrent,
        torqueFactor?.toStringAsFixed(10) ?? '',
        torque?.toStringAsFixed(3) ?? '',
        unit,
        measurement,
        measuringMethod,
        result,
        checksumOk ? 'OK' : 'NG',
        _escape(raw),
      ].join(',');

  static String _escape(String value) {
    final safe = value.replaceAll('\"', '\"\"');
    return '\"$safe\"';
  }
}
