import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

class TcpTransport {
  Socket? _socket;
  ServerSocket? _server;
  StreamSubscription<Socket>? _serverSub;
  StreamSubscription<Uint8List>? _socketSub;
  final StreamController<Uint8List> _data = StreamController<Uint8List>.broadcast();

  Stream<Uint8List> get dataStream => _data.stream;
  bool get isConnected => _socket != null || _server != null;

  Future<bool> start({required String role, required String ip, required int port}) async {
    await stop();
    if (role == 'CLIENT') {
      final socket = await Socket.connect(ip, port, timeout: const Duration(seconds: 5));
      _attach(socket);
      return true;
    }

    // SERVER: bind on all local interfaces. The configured IP is retained in
    // settings as the address the DTM45/peer should connect to.
    _server = await ServerSocket.bind(InternetAddress.anyIPv4, port);
    _serverSub = _server!.listen((socket) {
      _socket?.destroy();
      _attach(socket);
    });
    return true;
  }

  void _attach(Socket socket) {
    _socket = socket;
    _socketSub?.cancel();
    _socketSub = socket.listen(
      (bytes) => _data.add(Uint8List.fromList(bytes)),
      onDone: () {
        _socket = null;
      },
      onError: (_) {
        _socket = null;
      },
    );
  }

  Future<void> stop() async {
    await _socketSub?.cancel();
    _socketSub = null;
    _socket?.destroy();
    _socket = null;
    await _serverSub?.cancel();
    _serverSub = null;
    await _server?.close();
    _server = null;
  }

  Future<void> dispose() async {
    await stop();
    await _data.close();
  }
}
