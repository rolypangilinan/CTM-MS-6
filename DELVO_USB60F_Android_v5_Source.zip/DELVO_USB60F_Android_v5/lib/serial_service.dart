import 'dart:async';
import 'dart:typed_data';

import 'package:usb_serial/usb_serial.dart';

import 'models.dart';

class UsbSerialTransport {
  static const int ratocVendorId = 0x0584;
  static const Set<int> ratocUsb60fProductIds = {0xB020, 0xB022};

  UsbPort? _port;
  StreamSubscription<Uint8List>? _subscription;
  final StreamController<Uint8List> _data = StreamController<Uint8List>.broadcast();

  Stream<Uint8List> get dataStream => _data.stream;
  UsbDevice? connectedDevice;
  bool get isConnected => _port != null;

  Future<List<UsbDevice>> listDevices() => UsbSerial.listDevices();

  bool isRatocUsb60f(UsbDevice d) =>
      d.vid == ratocVendorId && ratocUsb60fProductIds.contains(d.pid);

  Future<bool> connect(UsbDevice device, SerialConfig settings, {bool forceRatocFtdi = false}) async {
    await disconnect();
    UsbPort? port;
    if (forceRatocFtdi || isRatocUsb60f(device)) {
      port = await UsbSerial.createFromDeviceId(device.deviceId, UsbSerial.FTDI);
    } else {
      port = await device.create();
      port ??= await UsbSerial.createFromDeviceId(device.deviceId, UsbSerial.FTDI);
    }
    if (port == null) return false;
    if (!await port.open()) return false;

    await port.setDTR(true);
    await port.setRTS(true);
    await port.setPortParameters(
      settings.baudRate,
      settings.dataBits,
      settings.stopBits == 2 ? UsbPort.STOPBITS_2 : UsbPort.STOPBITS_1,
      settings.parity,
    );

    _port = port;
    connectedDevice = device;
    _subscription = port.inputStream?.listen(
      _data.add,
      onError: (_) => disconnect(),
      onDone: disconnect,
    );
    return true;
  }

  Future<void> disconnect() async {
    await _subscription?.cancel();
    _subscription = null;
    try {
      await _port?.close();
    } catch (_) {}
    _port = null;
    connectedDevice = null;
  }

  Future<void> dispose() async {
    await disconnect();
    await _data.close();
  }
}
