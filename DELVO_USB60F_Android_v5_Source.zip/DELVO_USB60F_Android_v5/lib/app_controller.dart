import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:usb_serial/usb_serial.dart';

import 'csv_logger.dart';
import 'delvo_parser.dart';
import 'models.dart';
import 'preferences_service.dart';
import 'serial_service.dart';
import 'tcp_service.dart';

class DelvoController extends ChangeNotifier {
  final monitorSerial = UsbSerialTransport();
  final checkerSerial = UsbSerialTransport();
  final monitorTcp = TcpTransport();
  final parser = DelvoParser();
  final checkerParser = TorqueCheckerParser();
  final logger = CsvLogger();
  final prefs = PreferencesService();

  StreamSubscription<Uint8List>? _monitorSerialSub;
  StreamSubscription<Uint8List>? _checkerSerialSub;
  StreamSubscription<Uint8List>? _tcpSub;
  StreamSubscription<UsbEvent>? _usbSub;

  Timer? _pythonQrTimer;
  final HttpClient _httpClient = HttpClient();
  bool _pythonPollBusy = false;
  int? _lastPythonScanId;
  double? _lastPythonServerStartTime;

  SystemConfig system = const SystemConfig();
  CommunicationConfig communication = const CommunicationConfig();
  Map<int, ChannelConfig> channels = {};

  List<UsbDevice> usbDevices = [];
  UsbDevice? monitorDevice;
  UsbDevice? checkerDevice;
  bool monitorConnected = false;
  bool checkerConnected = false;
  bool ready = false;

  int? channel;
  int? convertedCurrent;
  double? convertedTorque;
  int? measurement;
  String result = '--';
  bool? checksumOk;
  String rawText = '';
  String rawHex = '';
  String csvPath = '';
  final List<FasteningRecord> history = [];
  String currentKittingNumber = '';
  final List<KittingScan> kittingScans = [];

  bool pythonServerConnected = false;
  String pythonQrStatus = 'Not connected';
  String pythonQrLastError = '';
  DateTime? pythonQrLastReceivedAt;
  String pythonQrLastSource = '';

  String _monitorBuffer = '';
  String _checkerBuffer = '';

  bool torqueConversionActive = false;
  double? latestCheckerTorque;
  DateTime? latestCheckerTime;
  Dtm45Packet? latestMonitorPacket;
  DateTime? latestMonitorTime;
  int _monitorSeq = 0;
  int _checkerSeq = 0;
  int _pairedMonitorSeq = -1;
  int _pairedCheckerSeq = -1;
  final List<TorqueTrial> torqueTrials = [];

  Future<void> initialize() async {
    system = await prefs.loadSystem();
    communication = await prefs.loadCommunication();
    channels = await prefs.loadChannels();
    currentKittingNumber = await prefs.loadCurrentKittingNumber();
    if (currentKittingNumber.isNotEmpty) {
      kittingScans.add(KittingScan(value: currentKittingNumber, timestamp: DateTime.now(), processNumber: communication.processNumber));
    }
    csvPath = await logger.currentPath();

    _monitorSerialSub = monitorSerial.dataStream.listen(_onMonitorBytes);
    _checkerSerialSub = checkerSerial.dataStream.listen(_onCheckerBytes);
    _tcpSub = monitorTcp.dataStream.listen(_onMonitorBytes);
    _usbSub = UsbSerial.usbEventStream?.listen((_) => refreshUsbDevices());
    await refreshUsbDevices();
    await restartPythonQrSync();
    ready = true;
    notifyListeners();
  }

  Future<void> refreshUsbDevices() async {
    usbDevices = await monitorSerial.listDevices();
    if (!monitorConnected) {
      monitorDevice = _chooseMonitorDevice(monitorDevice);
    }
    if (!checkerConnected) {
      checkerDevice = _chooseCheckerDevice(checkerDevice);
    }
    notifyListeners();
  }

  UsbDevice? _chooseMonitorDevice(UsbDevice? current) {
    if (current != null && usbDevices.any((d) => d.deviceId == current.deviceId)) return current;
    for (final d in usbDevices) {
      if (monitorSerial.isRatocUsb60f(d)) return d;
    }
    return usbDevices.isNotEmpty ? usbDevices.first : null;
  }

  UsbDevice? _chooseCheckerDevice(UsbDevice? current) {
    if (current != null && usbDevices.any((d) => d.deviceId == current.deviceId)) return current;
    for (final d in usbDevices) {
      if (d.deviceId != monitorDevice?.deviceId) return d;
    }
    return null;
  }

  void selectMonitorDevice(UsbDevice? d) {
    monitorDevice = d;
    if (checkerDevice?.deviceId == d?.deviceId) checkerDevice = null;
    notifyListeners();
  }

  void selectCheckerDevice(UsbDevice? d) {
    checkerDevice = d;
    notifyListeners();
  }

  Future<bool> connectMonitor() async {
    await disconnectMonitor();
    if (communication.monitorMode == 'ETHERNET') {
      try {
        monitorConnected = await monitorTcp.start(
          role: communication.ethernetRole,
          ip: communication.standbyIp,
          port: communication.standbyPort,
        );
      } catch (_) {
        monitorConnected = false;
      }
    } else {
      final d = monitorDevice;
      if (d == null) return false;
      monitorConnected = await monitorSerial.connect(
        d,
        communication.monitorSerial,
        forceRatocFtdi: monitorSerial.isRatocUsb60f(d),
      );
    }
    notifyListeners();
    return monitorConnected;
  }

  Future<void> disconnectMonitor() async {
    await monitorSerial.disconnect();
    await monitorTcp.stop();
    monitorConnected = false;
    notifyListeners();
  }

  Future<bool> connectChecker() async {
    await disconnectChecker();
    final d = checkerDevice;
    if (d == null) return false;
    checkerConnected = await checkerSerial.connect(d, communication.checkerSerial);
    notifyListeners();
    return checkerConnected;
  }

  Future<void> disconnectChecker() async {
    await checkerSerial.disconnect();
    checkerConnected = false;
    notifyListeners();
  }

  void _onMonitorBytes(Uint8List bytes) {
    final text = latin1.decode(bytes, allowInvalid: true);
    final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' ');
    rawText = _tail('$rawText$text', 8000);
    final hexParts = ('$rawHex $hex').trim().split(RegExp(r'\s+'));
    rawHex = hexParts.length <= 4000 ? hexParts.join(' ') : hexParts.sublist(hexParts.length - 4000).join(' ');

    _monitorBuffer += text;
    final lines = _monitorBuffer.split(RegExp(r'\r\n|\n|\r'));
    _monitorBuffer = lines.removeLast();
    for (final line in lines) {
      if (line.isNotEmpty) _processMonitorLine(line);
    }
    notifyListeners();
  }

  Future<void> _processMonitorLine(String line) async {
    final packet = parser.parseLine(line);
    if (packet == null) return;
    latestMonitorPacket = packet;
    latestMonitorTime = DateTime.now();
    _monitorSeq++;

    channel = packet.channel;
    convertedCurrent = packet.convertedCurrent;
    measurement = packet.measurement;
    checksumOk = packet.checksumOk;

    final cfg = channels[packet.channel] ?? ChannelConfig(
      channel: packet.channel,
      torqueFactor: 9.99,
      torqueUpper: 8,
      torqueLower: 0,
      signalUpper: 60000,
      signalLower: 0,
    );
    channels.putIfAbsent(packet.channel, () => cfg);

    double? torque;
    if (cfg.factorConfigured) torque = packet.convertedCurrent * cfg.torqueFactor;
    convertedTorque = torque;

    if (!packet.checksumOk) {
      result = 'NG';
    } else if (torque == null) {
      result = '--';
    } else {
      final torqueOk = torque >= cfg.torqueLower && torque <= cfg.torqueUpper;
      final measurementOk = packet.measurement >= cfg.signalLower && packet.measurement <= cfg.signalUpper;
      result = torqueOk && measurementOk ? 'OK' : 'NG';
    }

    final record = FasteningRecord(
      timestamp: DateTime.now(),
      processNumber: communication.processNumber,
      kittingNumber: currentKittingNumber,
      channel: packet.channel,
      convertedCurrent: packet.convertedCurrent,
      torqueFactor: cfg.factorConfigured ? cfg.torqueFactor : null,
      torque: torque,
      unit: 'Nm',
      measurement: packet.measurement,
      measuringMethod: system.measuringMethod,
      result: result,
      checksumOk: packet.checksumOk,
      raw: line,
    );
    if (system.autoLog) await logger.append(record);
    history.insert(0, record);
    if (history.length > 100) history.removeLast();

    _tryPairTorqueTrial();
    notifyListeners();
  }

  void _onCheckerBytes(Uint8List bytes) {
    final text = latin1.decode(bytes, allowInvalid: true);
    _checkerBuffer += text;
    final lines = _checkerBuffer.split(RegExp(r'\r\n|\n|\r'));
    _checkerBuffer = lines.removeLast();
    for (final line in lines) {
      final v = checkerParser.parseLine(line);
      if (v != null) {
        latestCheckerTorque = v;
        latestCheckerTime = DateTime.now();
        _checkerSeq++;
        _tryPairTorqueTrial();
      }
    }
    notifyListeners();
  }

  void _tryPairTorqueTrial() {
    if (!torqueConversionActive) return;
    final p = latestMonitorPacket;
    final t = latestCheckerTorque;
    final pt = latestMonitorTime;
    final tt = latestCheckerTime;
    if (p == null || t == null || pt == null || tt == null) return;
    if (_pairedMonitorSeq == _monitorSeq || _pairedCheckerSeq == _checkerSeq) return;
    if (pt.difference(tt).abs() > const Duration(seconds: 8)) return;
    if (t < system.effectiveMin || t > system.effectiveMax) return;
    if (torqueTrials.length >= system.trialCount) return;

    torqueTrials.add(TorqueTrial(
      number: torqueTrials.length + 1,
      channel: p.channel,
      measuredTorque: t,
      convertedCurrent: p.convertedCurrent,
      timestamp: DateTime.now(),
    ));
    _pairedMonitorSeq = _monitorSeq;
    _pairedCheckerSeq = _checkerSeq;
    notifyListeners();
  }

  bool addManualTorqueTrial(double measuredTorque) {
    final p = latestMonitorPacket;
    if (p == null || measuredTorque < system.effectiveMin || measuredTorque > system.effectiveMax) return false;
    if (torqueTrials.length >= system.trialCount) return false;
    torqueTrials.add(TorqueTrial(
      number: torqueTrials.length + 1,
      channel: p.channel,
      measuredTorque: measuredTorque,
      convertedCurrent: p.convertedCurrent,
      timestamp: DateTime.now(),
    ));
    notifyListeners();
    return true;
  }

  void deleteTorqueTrial(int index) {
    if (index < 0 || index >= torqueTrials.length) return;
    torqueTrials.removeAt(index);
    for (var i = 0; i < torqueTrials.length; i++) {
      final old = torqueTrials[i];
      torqueTrials[i] = TorqueTrial(
        number: i + 1,
        channel: old.channel,
        measuredTorque: old.measuredTorque,
        convertedCurrent: old.convertedCurrent,
        timestamp: old.timestamp,
      );
    }
    notifyListeners();
  }

  void clearTorqueTrials() {
    torqueTrials.clear();
    _pairedMonitorSeq = -1;
    _pairedCheckerSeq = -1;
    notifyListeners();
  }

  double? get trialAverageTorque {
    if (torqueTrials.isEmpty) return null;
    return torqueTrials.map((e) => e.measuredTorque).reduce((a, b) => a + b) / torqueTrials.length;
  }

  double? get trialAverageCurrent {
    if (torqueTrials.isEmpty) return null;
    return torqueTrials.map((e) => e.convertedCurrent.toDouble()).reduce((a, b) => a + b) / torqueTrials.length;
  }

  double? get calculatedTorqueFactor {
    if (torqueTrials.isEmpty) return null;
    // The Nitto Kohki Windows application matches the average of each
    // individual trial ratio (measured torque / converted current), rather
    // than simply dividing the two displayed averages.
    final ratios = torqueTrials
        .where((e) => e.convertedCurrent != 0)
        .map((e) => e.measuredTorque / e.convertedCurrent)
        .toList();
    if (ratios.isEmpty) return null;
    return ratios.reduce((a, b) => a + b) / ratios.length;
  }

  Future<bool> applyTorqueFactor() async {
    if (torqueTrials.isEmpty) return false;
    final f = calculatedTorqueFactor;
    if (f == null) return false;
    final ch = torqueTrials.last.channel;
    final old = channels[ch] ?? ChannelConfig(
      channel: ch,
      torqueFactor: 9.99,
      torqueUpper: 8,
      torqueLower: 0,
      signalUpper: 60000,
      signalLower: 0,
    );
    channels[ch] = old.copyWith(torqueFactor: f, updatedAt: DateTime.now());
    await prefs.saveChannels(channels);
    notifyListeners();
    return true;
  }


  Future<void> restartPythonQrSync() async {
    _pythonQrTimer?.cancel();
    _pythonQrTimer = null;
    _lastPythonScanId = null;
    _lastPythonServerStartTime = null;
    pythonQrLastError = '';

    if (communication.kittingQrMode != 'PYTHON') {
      pythonServerConnected = false;
      pythonQrStatus = 'USB HID / manual mode';
      notifyListeners();
      return;
    }

    pythonQrStatus = 'Connecting to Python server...';
    notifyListeners();

    await pollPythonKittingQr();

    final ms = communication.pythonPollMs.clamp(250, 5000).toInt();
    _pythonQrTimer = Timer.periodic(Duration(milliseconds: ms), (_) {
      pollPythonKittingQr();
    });
  }

  String _normalizedPythonServerUrl() {
    var base = communication.pythonServerUrl.trim();
    if (base.isEmpty) return '';
    if (!base.startsWith('http://') && !base.startsWith('https://')) {
      base = 'http://$base';
    }
    while (base.endsWith('/')) {
      base = base.substring(0, base.length - 1);
    }
    return base;
  }

  Future<bool> pollPythonKittingQr() async {
    if (communication.kittingQrMode != 'PYTHON') return false;
    if (_pythonPollBusy) return pythonServerConnected;
    final base = _normalizedPythonServerUrl();
    if (base.isEmpty) {
      pythonServerConnected = false;
      pythonQrStatus = 'Python server URL is empty';
      notifyListeners();
      return false;
    }

    _pythonPollBusy = true;
    try {
      final processNo = communication.processNumber.clamp(1, 9).toInt();
      final uri = Uri.parse('$base/api/delvo/latest_kitting?process=$processNo');
      final req = await _httpClient.getUrl(uri).timeout(const Duration(seconds: 2));
      req.headers.set(HttpHeaders.acceptHeader, 'application/json');
      final resp = await req.close().timeout(const Duration(seconds: 2));
      final body = await resp.transform(utf8.decoder).join();

      if (resp.statusCode != 200) {
        throw HttpException('HTTP ${resp.statusCode}: $body', uri: uri);
      }

      final data = jsonDecode(body);
      if (data is! Map || data['success'] != true) {
        throw FormatException('Invalid DELVO QR API response: $body');
      }

      final returnedProcess = (data['process_no'] as num?)?.toInt();
      if (returnedProcess != null && returnedProcess != processNo) {
        throw FormatException('DELVO QR API returned Process $returnedProcess, expected Process $processNo');
      }

      pythonServerConnected = true;
      pythonQrLastError = '';
      pythonQrLastSource = data['source']?.toString() ?? 'p$processNo';
      final scanId = (data['scan_id'] as num?)?.toInt() ?? 0;
      final qr = data['kitting_qr']?.toString().trim() ?? '';
      final ts = data['timestamp']?.toString();
      final serverStart = (data['server_start_time'] as num?)?.toDouble();

      // If the Python program restarted, reset our scan-id comparison.
      if (serverStart != null &&
          _lastPythonServerStartTime != null &&
          serverStart != _lastPythonServerStartTime) {
        _lastPythonScanId = null;
      }
      _lastPythonServerStartTime = serverStart;

      // The API is non-destructive. A new scan is detected by scan_id.
      if (scanId > 0 && scanId != _lastPythonScanId && qr.isNotEmpty) {
        _lastPythonScanId = scanId;
        await registerKittingScan(qr);
        pythonQrLastReceivedAt = ts == null ? DateTime.now() : (DateTime.tryParse(ts) ?? DateTime.now());
        pythonQrStatus = 'QR received automatically';
      } else {
        _lastPythonScanId ??= scanId;
        pythonQrStatus = scanId > 0 ? 'Connected - waiting for next QR' : 'Connected - no QR received yet';
      }

      notifyListeners();
      return true;
    } catch (e) {
      pythonServerConnected = false;
      pythonQrLastError = e.toString();
      pythonQrStatus = 'Python server disconnected';
      notifyListeners();
      return false;
    } finally {
      _pythonPollBusy = false;
    }
  }

  Future<bool> testPythonQrConnection() async {
    return pollPythonKittingQr();
  }

  Future<bool> registerKittingScan(String raw) async {
    final value = raw.replaceAll(RegExp(r'[\r\n]+'), '').trim();
    if (value.isEmpty) return false;

    // Ignore a repeated scan of the currently active QR. The Python mirror can
    // legitimately expose the same value more than once after a re-validation,
    // but the active kitting should not create duplicate tablet history rows.
    if (value == currentKittingNumber) return false;

    currentKittingNumber = value;
    kittingScans.insert(0, KittingScan(
      value: value,
      timestamp: DateTime.now(),
      processNumber: communication.processNumber,
    ));
    if (kittingScans.length > 20) kittingScans.removeLast();
    await prefs.saveCurrentKittingNumber(value);
    notifyListeners();
    return true;
  }

  Future<void> clearKittingNumber() async {
    currentKittingNumber = '';
    await prefs.saveCurrentKittingNumber('');
    notifyListeners();
  }

  Future<void> updateChannel(ChannelConfig config) async {
    channels[config.channel] = config.copyWith(updatedAt: DateTime.now());
    await prefs.saveChannels(channels);
    notifyListeners();
  }

  Future<void> updateSystem(SystemConfig config) async {
    system = config;
    await prefs.saveSystem(system);
    notifyListeners();
  }

  Future<void> updateCommunication(CommunicationConfig config) async {
    final old = communication;
    final processChanged = old.processNumber != config.processNumber;
    final qrChanged = old.kittingQrMode != config.kittingQrMode ||
        old.pythonServerUrl != config.pythonServerUrl ||
        processChanged ||
        old.pythonPollMs != config.pythonPollMs;

    communication = config;
    await prefs.saveCommunication(communication);

    // Do not carry a Process 1 kitting into Process 2 (or any other reassignment).
    // The newly assigned process must receive its own validated QR from Python.
    if (processChanged) {
      currentKittingNumber = '';
      kittingScans.clear();
      await prefs.saveCurrentKittingNumber('');
      _lastPythonScanId = null;
      pythonQrLastReceivedAt = null;
    }

    if (qrChanged) {
      await restartPythonQrSync();
    } else {
      notifyListeners();
    }
  }

  void clearRaw() {
    rawText = '';
    rawHex = '';
    notifyListeners();
  }

  String deviceLabel(UsbDevice d) {
    final vid = (d.vid ?? 0).toRadixString(16).padLeft(4, '0').toUpperCase();
    final pid = (d.pid ?? 0).toRadixString(16).padLeft(4, '0').toUpperCase();
    final name = monitorSerial.isRatocUsb60f(d) ? 'RATOC USB60F' : (d.productName ?? 'USB serial');
    final serial = (d.serial ?? '').isEmpty ? '' : ' SN:${d.serial}';
    return '$name  VID:$vid PID:$pid ID:${d.deviceId}$serial';
  }

  String _tail(String s, int max) => s.length <= max ? s : s.substring(s.length - max);

  @override
  void dispose() {
    _monitorSerialSub?.cancel();
    _checkerSerialSub?.cancel();
    _tcpSub?.cancel();
    _usbSub?.cancel();
    _pythonQrTimer?.cancel();
    _httpClient.close(force: true);
    monitorSerial.dispose();
    checkerSerial.dispose();
    monitorTcp.dispose();
    super.dispose();
  }
}
