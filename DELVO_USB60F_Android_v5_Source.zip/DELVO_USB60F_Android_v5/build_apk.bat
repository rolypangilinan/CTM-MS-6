@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo DELVO Tablet Monitor v0.3.0 - Android APK Build
echo ===============================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter is not available in PATH.
  echo Install Flutter, reopen Command Prompt, then run this file again.
  pause
  exit /b 1
)
flutter doctor
if errorlevel 1 echo NOTE: Review any Flutter Doctor warnings above.
flutter pub get
if errorlevel 1 goto :fail
flutter build apk --release
if errorlevel 1 goto :fail
echo.
echo APK CREATED:
echo %CD%\build\app\outputs\flutter-apk\app-release.apk
echo.
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Copy the error shown above and send it for troubleshooting.
pause
exit /b 1
