# Windows-to-Tablet Feature Mapping

| Windows / Production function | Android tablet v0.5.0 |
|---|---|
| Screw fastening monitor | Implemented |
| Kitting Number display | Implemented |
| Kitting QR reader | Python/Arduino process bridge for P1-P9; USB HID fallback retained |
| Kitting QR scan history | Implemented with process number |
| Attach Kitting Number to tightening record | Implemented |
| Kitting Number in CSV | Implemented; CSV also includes Process |
| Operation channel | Parsed from DTM45 packet |
| Converted torque | Calculated from converted current × channel T.C. factor |
| Signal | Parsed from DTM45 packet |
| Result OK/NG | Calculated from torque + measurement judgement limits + checksum |
| History / list | Implemented in Fastening history |
| Torque conversion screen | Implemented |
| Torque Checker communication | Implemented as second USB serial connection |
| 10-trial measurement | Configurable trial count |
| Average measured torque/current | Implemented |
| T.C. factor | Average of per-trial torque/current ratios, matching supplied Windows data |
| Clear calibration table | Implemented |
| Apply conversion factor | Implemented |
| Judgement value setting | Implemented per channel |
| Torque upper/lower limits | Implemented |
| Signal/measurement upper/lower limits | Implemented |
| Communication: RS-232C | Implemented |
| Communication: Ethernet Server/Client | Implemented |
| DTM45 serial parameters | Implemented |
| Torque Checker serial parameters | Implemented |
| Device name | Implemented |
| Language setting | English available |
| Number of conversion trials | Implemented |
| Automatic CSV output | Implemented |
| CSV output folder | Visible Internal storage/Download/DELVO mirror + private backup + Share CSV |
| Torque checker unit | Setting included |
| Effective range | Implemented |
| Measuring method SIGNAL/TIME | Implemented |
| RATOC USB60F VID 0584/PID B020 | Supported |
| RATOC device observed as VID 0584/PID B022 | Supported |
| Powered OTG hub with DTM45 + checker + QR | DTM45 + checker on tablet hub; QR may stay on Arduino/Python |
| Same APK for Process 1-9 | Implemented; process assignment saved per tablet |
| Process-specific Python QR API | Implemented: `/api/delvo/latest_kitting?process=1..9` |
| Prevent ID QR from replacing Kitting QR | DELVO bridge publishes only validated process Kitting QR |
