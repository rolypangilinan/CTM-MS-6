# DELVO Tablet Monitor v0.5.0 - Process 1-9 Kitting QR Bridge

Android/Flutter reimplementation of the Nitto Kohki DELVO Screw Fastening Monitor functions required for the HIBLOW tablet setup, now with Kitting QR capture.

## New in v0.5.0 - One APK for Process 1 to Process 9

The same Android APK can now be installed on every DELVO tablet from **Process 1 through Process 9**. Each tablet is assigned once in **Communication setting > Kitting QR Reader / Python Bridge > This tablet is assigned to**.

Recommended architecture:

```
Process Kitting QR -> existing process page / scanner -> Python Flask validation
                                                   |
                                                   v
                                      Process-specific DELVO mirror
                                                   | LAN / Wi-Fi
                                                   v
                                      DELVO tablet assigned to P1..P9
```

The Python API now supports:

```
GET /api/delvo/latest_kitting?process=1
GET /api/delvo/latest_kitting?process=2
...
GET /api/delvo/latest_kitting?process=9
GET /api/delvo/status
```

A process QR is published to the DELVO mirror **only after `/api/validate_kitting_qr` accepts it for that process**. This prevents a wrong-process or invalid QR from becoming the active Kitting Number on the tablet. The existing operator-ID QR path is not mirrored into the DELVO Kitting Number.

When the tablet assignment is changed, the current Kitting Number is cleared automatically so a Process 1 QR cannot remain active after assigning the tablet to Process 2, etc. Each tightening CSV row now also contains a **Process** column.

Example response for a Process 4 tablet:

```json
{
  "success": true,
  "source": "p4",
  "process_no": 4,
  "scan_id": 18,
  "kitting_qr": "29/09/26-0018 3J73802302 0001",
  "kitting_no": 18,
  "job_order": "3J73802302",
  "model_code": "80HP...",
  "timestamp": "2026-09-29 11:55:10"
}
```

### Important behavior

Processes 1-9 use the existing process QR validation flow. The Python program does not require Wi-Fi on the Arduino Mega; the Mega remains connected to the Windows PC by USB/serial and the tablet talks only to the Flask PC over LAN/Wi-Fi.

The older v0.4.0 `source=p1` / `source=ms` query remains accepted by the Python API for backward compatibility, but v0.5.0 tablets should use the process-number query.


## Confirmed from real equipment testing

The Android tablet successfully received a DTM45 record through the RATOC USB60F using **19200 / 8 data bits / no parity / 1 stop bit**.

Confirmed DTM45 record shape:

```
CH1:1624-2456,<SUM><CR><LF>
```

- `CH1` = operation channel
- `1624` = converted current
- `2456` = SIGNAL value in the current DTM45 measuring mode
- `<SUM>` = one-byte checksum
- `CR LF` = record terminator

The real Windows setup showed CH1 T.C. factor **0.0048372085**, torque judgment **1.000 to 8.000 Nm**, and signal judgment **0 to 60000**. With current `1624`, the tablet calculation is approximately `7.855 Nm`, matching the Windows monitor.

The Windows torque-conversion screen was also matched: its T.C. factor is the **average of the individual trial ratios** (`measured torque / converted current`), not simply the displayed average torque divided by displayed average current.

## New in v0.3.0 - Kitting QR Reader

A dedicated **Kitting Number** box is now shown on the main monitor.

Recommended scanner configuration:

- USB HID / Keyboard mode
- Enter or CR suffix after every QR scan
- Connect the scanner to a USB data port on the powered OTG hub

Behavior:

1. The Kitting QR scan field stays focused on the main monitor.
2. Scan the Kitting QR code.
3. Scanner characters are received like keyboard input.
4. Enter/CR registers the scan.
5. The large **Kitting Number** box immediately changes to the new scanned value.
6. Every scan is added to **Recent Kitting QR scans** with date/time.
7. The most recent Kitting Number becomes the active number for subsequent tightening records.
8. Every fastening history row and CSV row stores the active Kitting Number.
9. The last Kitting Number is retained after restarting the app until it is replaced or cleared.

The main screen also includes a QR-scanner focus icon. Use it if another field was touched and you want to restore scanner focus.

### Recommended powered hub layout

```
Android Tablet USB-C
        |
        v
Powered USB-C OTG / PD Hub
   |         |          |
   |         |          +--> Kitting QR Reader (USB HID)
   |         +-------------> Torque Checker
   +-----------------------> RATOC USB60F -> DTM45
```

A passive USB Y-splitter is not recommended. Use a real powered USB hub with USB data ports and Power Delivery input.

## Functions included

### Main Screw Fastening Monitor
- Kitting Number QR display
- USB HID / keyboard-wedge QR scan input
- Recent Kitting QR scan history
- Operation channel
- Converted current
- Converted torque in Nm
- SIGNAL or TIME measurement value
- Automatic OK/NG judgment
- DTM45 checksum validation
- Fastening history, including Kitting Number
- Raw communication monitor
- CSV logging and Share CSV

### Judgement Value Setting
Per operation channel:
- Torque conversion factor
- Output torque upper limit
- Output torque lower limit
- Measurement/SIGNAL upper limit
- Measurement/SIGNAL lower limit
- Updated date/time
- Table view of all channel settings

Initial project defaults mirror the supplied Windows screenshot for CH1:
- T.C. factor: `0.0048372085`
- Torque upper: `8.000 Nm`
- Torque lower: `1.000 Nm`
- Signal upper: `60000`
- Signal lower: `0`

CH2-CH14 retain `9.99` as the unconfigured/default factor until calibrated.

### Torque Conversion
- Torque Checker USB serial connection
- Automatic capture of Torque Checker value + DTM45 converted current as one trial
- Number of trials selectable from System Setting
- Trial table
- Average torque
- Average current
- T.C. factor calculation matching the Windows application
- Apply calculated T.C. factor to the detected operation channel
- Clear/restart calibration trials

For automatic pairing, Torque Checker and DTM45 readings received within 8 seconds are treated as one trial while the Torque Conversion screen is open.

### Communication Setting
DTM45 / screw fastening monitor:
- RS-232C or Ethernet
- USB device selection
- Baud rate
- Data bits
- Parity
- Stop bits
- Ethernet Server / Client
- Standby IP
- Standby port

Torque Checker:
- Separate USB serial device selection
- Baud rate
- Data bits
- Parity
- Stop bits
- Connect / Disconnect

Kitting QR Reader:
- USB HID / Keyboard mode guidance
- No COM port configuration required in HID mode
- Enter/CR suffix recommended

Default DTM45 serial setting is **19200, 8, None, 1**.

### System Setting
- Device name
- Language setting (English in this build)
- Number of Torque Conversion trials
- Automatic CSV data-log ON/OFF
- CSV output location display
- Torque Checker unit
- Effective torque-checker range
- Measuring method: SIGNAL / TIME

## RATOC USB60F support

Both hardware IDs observed/required by this project are accepted:

- VID `0584`, PID `B020`
- VID `0584`, PID `B022`

The tablet must support USB Host/OTG.

## Android CSV location

The v0.3 log filename is:

```
TighteningHistory_Process_Kitting_YYYYMMDD.csv
```

CSV columns include:

```
Timestamp,KittingNumber,Channel,ConvertedCurrent,TCFactor,Torque,Unit,Measurement,MeasuringMethod,Result,Checksum,Raw
```

Android uses application-specific external storage because modern Android restricts direct arbitrary-folder writes. The exact path is shown in System Setting and on the main monitor. Use **Share CSV** to copy/send the file to another location or system.

## Build APK on Windows

Install Flutter and Android Studio, then open this project and run:

```
flutter pub get
flutter build apk --release
```

or double-click:

```
build_apk.bat
```

APK output:

```
build\app\outputs\flutter-apk\app-release.apk
```

## QR scanner test procedure

1. Connect the powered OTG hub to the tablet.
2. Connect the DTM45 USB60F, Torque Checker, and QR reader to separate hub data ports.
3. Configure the QR reader as USB HID/Keyboard with Enter/CR suffix.
4. Open DELVO Tablet Monitor.
5. Tap the QR scanner icon if the scan field is not focused.
6. Scan a known Kitting QR.
7. Confirm the large Kitting Number box changes immediately.
8. Perform one tightening.
9. Open Fastening history and confirm the same Kitting Number is attached to the tightening record.
10. Share the CSV and confirm the KittingNumber column contains the scanned value.

## Production validation still required

Before making the Android app the sole production OK/NG authority:

1. Compare at least 20-30 identical fastening cycles side-by-side with the original Windows Nitto Kohki monitor.
2. Confirm torque, signal/time, channel, checksum and OK/NG match for every record.
3. Test deliberate NG cases above/below torque and signal limits.
4. Test CH2+ only after each channel has a real calibrated T.C. factor.
5. Verify the Torque Checker output format with the actual checker model.
6. Verify the actual production QR reader is configured as USB HID/Keyboard and sends Enter/CR after each scan.

## v0.3.1 - Visible CSV storage

The app now keeps its private backup **and** mirrors the active daily CSV to a normal, user-visible tablet folder:

`Internal storage/Download/DELVO/TighteningHistory_Process_Kitting_YYYYMMDD.csv`

On Samsung tablets this can normally be opened from:

**My Files > Internal storage > Download > DELVO**

The monitor screen also has an **Open Folder** button next to **Share CSV**. On Android 10 and later the public copy is created through Android MediaStore, so no broad storage permission is required.

If upgrading from an older build, the old file under `Android/data/...` is not moved by Android itself. When v0.3.1 starts, it publishes the current daily app backup into the visible `Download/DELVO` location; new fastening records are then mirrored there automatically.


## v0.4.0 - Python/Arduino Kitting QR Bridge

This version is designed for the existing HIBLOW R35D-B + Arduino Mega + Flask setup.

Recommended production path:

```
R35D-B -> Arduino Mega -> Windows Python/Flask -> LAN/Wi-Fi -> Android DELVO app
```

The QR scanner does **not** have to be connected to the tablet. The Arduino Mega does not need Wi-Fi.

### Required Python API

Use the modified Python file supplied with this release. It adds:

```
GET /api/delvo/latest_kitting?source=p1
GET /api/delvo/latest_kitting?source=ms
GET /api/delvo/status
```

`latest_kitting` is non-destructive. Reading it from Android does not clear the scan used by the existing browser UI.

Example response:

```json
{
  "success": true,
  "source": "p1",
  "scan_id": 12,
  "kitting_qr": "29/09/26-0005 3J73802302 0001",
  "timestamp": "2026-09-29 07:30:15",
  "server_start_time": 1790640000.0
}
```

Every real scanner event increments `scan_id`. The Android app polls the endpoint and automatically registers the QR whenever `scan_id` changes.

### Android setup

Open **Communication setting > Kitting QR Reader / Python Bridge** and select:

```
Python / Arduino
```

Enter the actual Windows PC IP and Flask port. The current Python program runs Flask on port `5001`, for example:

```
http://192.168.3.220:5001
```

Change `192.168.3.220` to the real IPv4 address of the Windows PC.

Choose the QR source:

- `Process 1 Kitting R35D-B` (`source=p1`) - recommended for the Process 1 DELVO tablet.
- `Material Setter Kitting R35D-B` (`source=ms`) - optional.

Default polling is 500 ms.

The Android application has `INTERNET` permission and allows local clear-text HTTP for communication with the Flask server on the factory LAN.

### Automatic behavior

When a new QR is scanned:

1. Arduino/Python receives the QR.
2. Existing scanner OFF/interlock commands continue unchanged.
3. Python updates the DELVO mirror with a new `scan_id`.
4. Android detects the changed `scan_id`.
5. The Kitting Number box updates automatically.
6. Subsequent DTM45 tightening records and CSV rows use that Kitting Number.

The original direct USB HID scanner mode is still available as a fallback.
