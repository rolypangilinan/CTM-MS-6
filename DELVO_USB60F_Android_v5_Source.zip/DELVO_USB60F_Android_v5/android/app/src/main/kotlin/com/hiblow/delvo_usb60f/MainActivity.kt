package com.hiblow.delvo_usb60f

import android.app.DownloadManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val storageChannel = "com.hiblow.delvo_usb60f/storage"
    private val relativeCsvPath = "${Environment.DIRECTORY_DOWNLOADS}/DELVO/"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            storageChannel
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "writeCsvPublic" -> {
                    val fileName = call.argument<String>("fileName")
                    val content = call.argument<String>("content")
                    if (fileName.isNullOrBlank() || content == null) {
                        result.error("BAD_ARGUMENT", "fileName/content missing", null)
                        return@setMethodCallHandler
                    }
                    try {
                        result.success(writeCsvPublic(fileName, content))
                    } catch (e: Exception) {
                        result.error("WRITE_FAILED", e.message, null)
                    }
                }

                "appendCsvPublic" -> {
                    val fileName = call.argument<String>("fileName")
                    val header = call.argument<String>("header") ?: ""
                    val content = call.argument<String>("content")
                    if (fileName.isNullOrBlank() || content == null) {
                        result.error("BAD_ARGUMENT", "fileName/content missing", null)
                        return@setMethodCallHandler
                    }
                    try {
                        result.success(appendCsvPublic(fileName, header, content))
                    } catch (e: Exception) {
                        result.error("APPEND_FAILED", e.message, null)
                    }
                }

                "openDownloads" -> {
                    try {
                        val intent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                        startActivity(intent)
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("OPEN_FAILED", e.message, null)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun publicDisplayPath(fileName: String): String =
        "Internal storage/Download/DELVO/$fileName"

    private fun findDownloadUri(fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null

        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection =
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
        val selectionArgs = arrayOf(fileName, relativeCsvPath)

        contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(
                    cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                )
                return ContentUris.withAppendedId(collection, id)
            }
        }
        return null
    }

    private fun createDownloadUri(fileName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativeCsvPath)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Files.getContentUri("external")
        }

        return contentResolver.insert(collection, values)
            ?: throw IllegalStateException("Unable to create CSV in Downloads")
    }

    private fun writeCsvPublic(fileName: String, content: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = findDownloadUri(fileName) ?: createDownloadUri(fileName)
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { writer ->
                writer.write(content)
            } ?: throw IllegalStateException("Unable to open public CSV")
            return publicDisplayPath(fileName)
        }

        @Suppress("DEPRECATION")
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "DELVO"
        )
        if (!dir.exists() && !dir.mkdirs()) {
            throw IllegalStateException("Unable to create Downloads/DELVO")
        }
        val file = File(dir, fileName)
        file.writeText(content)
        return file.absolutePath
    }

    private fun appendCsvPublic(fileName: String, header: String, content: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            var uri = findDownloadUri(fileName)
            val isNew = uri == null
            if (uri == null) uri = createDownloadUri(fileName)

            contentResolver.openOutputStream(uri, if (isNew) "wt" else "wa")
                ?.bufferedWriter()?.use { writer ->
                    if (isNew && header.isNotEmpty()) writer.write(header)
                    writer.write(content)
                } ?: throw IllegalStateException("Unable to append public CSV")
            return publicDisplayPath(fileName)
        }

        @Suppress("DEPRECATION")
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "DELVO"
        )
        if (!dir.exists() && !dir.mkdirs()) {
            throw IllegalStateException("Unable to create Downloads/DELVO")
        }
        val file = File(dir, fileName)
        if (!file.exists()) file.writeText(header)
        file.appendText(content)
        return file.absolutePath
    }
}
